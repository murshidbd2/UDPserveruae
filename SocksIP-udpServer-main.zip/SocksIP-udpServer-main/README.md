# SCRIPT UDPSERVER BY [@Rufu99](https://t.me/Rufu99)

![Selección_022](https://user-images.githubusercontent.com/67137156/206889505-370daa1a-3b70-4b7c-9cc2-2f703bb19b88.png)

# INSTALADOR DEL SCRIPT

wget https://raw.githubusercontent.com/rudi9999/SocksIP-udpServer/main/UDPserver.sh; chmod +x UDPserver.sh; ./UDPserver.sh

UDPserver Binary by team newtoolsworks :point_right: [AQUI](https://bitbucket.org/iopmx/udprequestserver/src/master/)

UDPclient Android SocksIP :point_right: [AQUI](https://play.google.com/store/apps/details?id=com.newtoolsworks.sockstunnel)

para colaborar con la traduccion en su idioma, contactar con :point_right: [@Rufu99](https://t.me/Rufu99)

To collaborate with the translation in your language, contact :point_right: [@Rufu99](https://t.me/Rufu99)
